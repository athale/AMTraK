%% Anushree R. Chaphalkar, IISER Pune
%% Created: June, 2013
%% Modified: June, 2016
function [infra,ultra,neutra]=tracorient(inoutpath, scal_fact, interval, timeUnit,distUnit,figg)
%% Storing intensity profiles of kymography tracks
%====================INPUT=================================================
% 1. Tracklist.txt
% 2. Variables:
%  inoutpath= 'd:/test'     % input-output path 
%  timeUnit = 'min'         % units of time
%====================OUTPUT================================================
% 1. Track_Orientation.txt
% 2. Track_Orientation.pdf
%==========================================================================
%--read coords of contours
INT=importdata([inoutpath, '/Tracklist.txt'],'\t', 1);
cont=INT.data;
%(Track number, xcoord, ycoord)
mn=min(cont(:,1));
mx=max(cont(:,1));
%--read kymograph matrix
kym=dlmread([inoutpath, '/OutputKymo.txt']);
siz=size(kym);
spacingXAxis= round(siz(2)/4);
spacingYAxis= round(siz(1)/4);
dirtxt=zeros(mx-mn,2);
infra=0;
ultra=0;
neutra=0;
figure(figg),
movegui(gcf, 'east');
set(gcf,'NumberTitle','off', 'Name', 'Track Direction');
imshow(imadjust(kym), 'InitialMagnification', 'fit')
axis ij, axis on;
axis normal;
set(gca,'fontname', 'Times New Roman',...
    'fontsize', 18,...
    'fontweight', 'bold',...
    'XTick', 0:spacingXAxis:siz(2),...
    'YTick', 0:spacingYAxis:siz(1)-1,...
    'XTicklabel', (0:spacingXAxis:siz(2)).*scal_fact,...
    'YTicklabel', (0:spacingYAxis:siz(1)-1).*interval);
xlabel(['Distance (',distUnit,')'  ]);
ylabel(['Time (',  timeUnit, ')']);
for g= mn: mx %grouping coords trackwise
    [row]= find(cont(:,1)== g);
        dirdisp=cont(row(end),2)-cont(row(1),2);
        dirtxt(g,:)=[g,dirdisp/abs(dirdisp)];%sign will indicate direction
    if dirdisp>0 % (+) =right
        figure(figg),hold on, plot(cont(row,2),cont(row,3), '--r', 'Linewidth',2)
        infra=infra+1;
    elseif dirdisp<0 % (-) =left
        figure(figg),hold on, plot(cont(row,2),cont(row,3), '--b', 'Linewidth',2)
        ultra=ultra+1;
    else % neutral
        figure(figg),hold on, plot(cont(row,2),cont(row,3), '--g', 'Linewidth',2)
        neutra=neutra+1;
    end
    figure(figg),hold on,
    text(cont(row(2),2), cont(row(2),3),...
        sprintf('%i',g),...
        'Color', 'k', ...
        'EdgeColor', 'r',...
        'BackgroundColor', 'y',...
        'VerticalAlignment', 'Top',...
        'HorizontalAlignment', 'Left',...
        'FontSize',8)
end

fid =fopen([inoutpath, '/Track_Orientation.txt'], 'w');
fprintf(fid, 'Track, Orientation\r\n');
fclose(fid);
dlmwrite([inoutpath, '/Track_Orientation.txt'], dirtxt,'-append', 'delimiter', '\t','newline', 'pc');
print(figure(figg), '-dpdf', [inoutpath, '/Track_Orientation.pdf'], '-r720');
end