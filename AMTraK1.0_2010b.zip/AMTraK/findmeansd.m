%% Anushree R. Chaphalkar
%% Created: June 2016
function [avg,sd]=findmeansd(matr)
avg=mean(matr);
sd=std(matr);
end